Project Output images
